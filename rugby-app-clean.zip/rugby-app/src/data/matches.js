export const matchesToday = [
  {
    league: 'Top 14',
    time: '14:30',
    home: 'Toulouse',
    away: 'Montpellier',
    homeScore: 28,
    awayScore: 14,
    status: 'finished'
  },
  {
    league: 'Top 14',
    time: '17:00',
    home: 'Racing 92',
    away: 'Lyon',
    homeScore: null,
    awayScore: null,
    status: 'scheduled'
  },
  {
    league: 'Premiership',
    time: '15:00',
    home: 'Saracens',
    away: 'Harlequins',
    homeScore: 21,
    awayScore: 17,
    status: 'finished'
  },
  {
    league: 'URBA Top 14',
    time: '19:00',
    home: 'San Isidro',
    away: 'Hindu',
    homeScore: null,
    awayScore: null,
    status: 'scheduled'
  },
  {
    league: 'URBA Top 14',
    time: '19:00',
    home: 'Belgrano',
    away: 'Alumni',
    homeScore: null,
    awayScore: null,
    status: 'scheduled'
  }
];
