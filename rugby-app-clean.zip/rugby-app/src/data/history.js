export const history = {
  'Top 14': [
    { date: '29/09', home: 'Toulouse', away: 'Bordeaux', homeScore: 35, awayScore: 21 },
    { date: '29/09', home: 'Lyon', away: 'Clermont', homeScore: 24, awayScore: 19 },
    { date: '22/09', home: 'Montpellier', away: 'La Rochelle', homeScore: 28, awayScore: 25 },
    { date: '22/09', home: 'Racing 92', away: 'Pau', homeScore: 31, awayScore: 17 },
    { date: '15/09', home: 'Bordeaux', away: 'Toulouse', homeScore: 19, awayScore: 42 },
    { date: '15/09', home: 'Clermont', away: 'Lyon', homeScore: 21, awayScore: 34 },
    { date: '08/09', home: 'La Rochelle', away: 'Montpellier', homeScore: 27, awayScore: 21 },
    { date: '08/09', home: 'Pau', away: 'Racing 92', homeScore: 14, awayScore: 38 }
  ],
  'Premiership': [
    { date: '29/09', home: 'Saracens', away: 'Bath', homeScore: 28, awayScore: 14 },
    { date: '29/09', home: 'Northampton', away: 'Gloucester', homeScore: 31, awayScore: 24 },
    { date: '22/09', home: 'Harlequins', away: 'Sale Sharks', homeScore: 25, awayScore: 18 },
    { date: '22/09', home: 'Leicester', away: 'Newcastle', homeScore: 19, awayScore: 10 },
    { date: '15/09', home: 'Bath', away: 'Saracens', homeScore: 21, awayScore: 29 },
    { date: '15/09', home: 'Gloucester', away: 'Northampton', homeScore: 20, awayScore: 18 },
    { date: '08/09', home: 'Sale Sharks', away: 'Harlequins', homeScore: 22, awayScore: 35 },
    { date: '08/09', home: 'Newcastle', away: 'Leicester', homeScore: 17, awayScore: 24 }
  ],
  'URBA Top 14': [
    { date: '28/09', home: 'San Isidro', away: 'Alumni', homeScore: 38, awayScore: 19 },
    { date: '28/09', home: 'Belgrano', away: 'Hindu', homeScore: 31, awayScore: 24 },
    { date: '21/09', home: 'Alumni', away: 'San Isidro', homeScore: 14, awayScore: 42 },
    { date: '21/09', home: 'Hindu', away: 'Belgrano', homeScore: 20, awayScore: 27 },
    { date: '14/09', home: 'San Isidro', away: 'Vélez Sársfield', homeScore: 35, awayScore: 12 },
    { date: '14/09', home: 'Belgrano', away: 'Barracas', homeScore: 28, awayScore: 14 },
    { date: '07/09', home: 'Vélez Sársfield', away: 'Alumni', homeScore: 18, awayScore: 29 },
    { date: '07/09', home: 'Barracas', away: 'Universitario', homeScore: 21, awayScore: 19 }
  ],
  'Six Nations': [
    { date: '15/03/2024', home: 'Francia', away: 'Irlanda', homeScore: 27, awayScore: 20 },
    { date: '14/03/2024', home: 'Gales', away: 'Inglaterra', homeScore: 20, awayScore: 34 },
    { date: '10/02/2024', home: 'Irlanda', away: 'Francia', homeScore: 17, awayScore: 38 },
    { date: '10/02/2024', home: 'Italia', away: 'Escocia', homeScore: 12, awayScore: 20 },
    { date: '03/02/2024', home: 'Francia', away: 'Gales', homeScore: 27, awayScore: 10 },
    { date: '03/02/2024', home: 'Inglaterra', away: 'Nueva Zelanda', homeScore: 20, awayScore: 34 }
  ]
};
