export const fixture = {
  'Top 14': [
    { date: '06/10', time: '14:30', home: 'Toulouse', away: 'Montpellier', status: 'played' },
    { date: '06/10', time: '17:00', home: 'Racing 92', away: 'Lyon', status: 'scheduled' },
    { date: '13/10', time: '15:00', home: 'Bordeaux', away: 'Clermont', status: 'scheduled' },
    { date: '13/10', time: '17:00', home: 'La Rochelle', away: 'Pau', status: 'scheduled' },
    { date: '20/10', time: '15:00', home: 'Toulouse', away: 'Racing 92', status: 'scheduled' },
    { date: '20/10', time: '17:00', home: 'Lyon', away: 'Montpellier', status: 'scheduled' },
    { date: '27/10', time: '15:00', home: 'Clermont', away: 'Bordeaux', status: 'scheduled' },
    { date: '27/10', time: '17:00', home: 'Pau', away: 'La Rochelle', status: 'scheduled' }
  ],
  'Premiership': [
    { date: '06/10', time: '15:00', home: 'Saracens', away: 'Harlequins', status: 'played' },
    { date: '13/10', time: '14:00', home: 'Northampton', away: 'Bath', status: 'scheduled' },
    { date: '13/10', time: '16:30', home: 'Gloucester', away: 'Sale Sharks', status: 'scheduled' },
    { date: '20/10', time: '14:00', home: 'Bath', away: 'Gloucester', status: 'scheduled' },
    { date: '20/10', time: '16:30', home: 'Saracens', away: 'Northampton', status: 'scheduled' },
    { date: '27/10', time: '14:00', home: 'Harlequins', away: 'Leicester', status: 'scheduled' },
    { date: '27/10', time: '16:30', home: 'Sale Sharks', away: 'Exeter', status: 'scheduled' }
  ],
  'URBA Top 14': [
    { date: '06/10', time: '19:00', home: 'San Isidro', away: 'Hindu', status: 'scheduled' },
    { date: '06/10', time: '19:00', home: 'Belgrano', away: 'Alumni', status: 'scheduled' },
    { date: '13/10', time: '19:00', home: 'San Isidro', away: 'Belgrano', status: 'scheduled' },
    { date: '13/10', time: '19:00', home: 'Alumni', away: 'Hindu', status: 'scheduled' },
    { date: '20/10', time: '19:00', home: 'Hindu', away: 'Vélez Sársfield', status: 'scheduled' },
    { date: '20/10', time: '19:00', home: 'Barracas', away: 'Alumni', status: 'scheduled' },
    { date: '27/10', time: '19:00', home: 'Belgrano', away: 'Universitario', status: 'scheduled' }
  ],
  'Six Nations': [
    { date: '04/02', time: '15:00', home: 'Francia', away: 'Gales', status: 'played' },
    { date: '04/02', time: '17:45', home: 'Irlanda', away: 'Nueva Zelanda', status: 'played' },
    { date: '11/02', time: '15:00', home: 'Escocia', away: 'Italia', status: 'played' },
    { date: '11/02', time: '17:45', home: 'Inglaterra', away: 'Francia', status: 'scheduled' },
    { date: '18/02', time: '15:00', home: 'Gales', away: 'Italia', status: 'scheduled' },
    { date: '18/02', time: '17:45', home: 'Irlanda', away: 'Francia', status: 'scheduled' }
  ]
};
