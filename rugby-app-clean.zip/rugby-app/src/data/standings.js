export const standings = {
  'Top 14': [
    { name: 'Toulouse', played: 10, wins: 9, losses: 1, draws: 0, points: 42 },
    { name: 'Lyon', played: 10, wins: 8, losses: 2, draws: 0, points: 39 },
    { name: 'Montpellier', played: 10, wins: 7, losses: 3, draws: 0, points: 36 },
    { name: 'Racing 92', played: 10, wins: 7, losses: 3, draws: 0, points: 35 },
    { name: 'Bordeaux', played: 10, wins: 6, losses: 4, draws: 0, points: 32 },
    { name: 'La Rochelle', played: 10, wins: 5, losses: 5, draws: 0, points: 28 },
    { name: 'Clermont', played: 10, wins: 4, losses: 6, draws: 0, points: 24 },
    { name: 'Pau', played: 10, wins: 3, losses: 7, draws: 0, points: 18 },
    { name: 'Brive', played: 10, wins: 2, losses: 8, draws: 0, points: 14 },
    { name: 'Toulon', played: 10, wins: 1, losses: 9, draws: 0, points: 10 }
  ],
  'Premiership': [
    { name: 'Saracens', played: 10, wins: 8, losses: 2, draws: 0, points: 38 },
    { name: 'Northampton', played: 10, wins: 7, losses: 3, draws: 0, points: 35 },
    { name: 'Bath', played: 10, wins: 7, losses: 3, draws: 0, points: 34 },
    { name: 'Gloucester', played: 10, wins: 6, losses: 4, draws: 0, points: 31 },
    { name: 'Harlequins', played: 10, wins: 5, losses: 5, draws: 0, points: 27 },
    { name: 'Sale Sharks', played: 10, wins: 4, losses: 6, draws: 0, points: 24 },
    { name: 'Leicester Tigers', played: 10, wins: 3, losses: 7, draws: 0, points: 20 },
    { name: 'Exeter Chiefs', played: 10, wins: 3, losses: 7, draws: 0, points: 19 },
    { name: 'Newcastle Falcons', played: 10, wins: 2, losses: 8, draws: 0, points: 15 },
    { name: 'London Irish', played: 10, wins: 1, losses: 9, draws: 0, points: 12 }
  ],
  'URBA Top 14': [
    { name: 'San Isidro', played: 9, wins: 8, losses: 1, draws: 0, points: 38 },
    { name: 'Belgrano', played: 9, wins: 7, losses: 2, draws: 0, points: 35 },
    { name: 'Hindu', played: 9, wins: 6, losses: 3, draws: 0, points: 32 },
    { name: 'Alumni', played: 9, wins: 5, losses: 4, draws: 0, points: 28 },
    { name: 'Vélez Sársfield', played: 9, wins: 4, losses: 5, draws: 0, points: 24 },
    { name: 'Barracas', played: 9, wins: 3, losses: 6, draws: 0, points: 20 },
    { name: 'Universitario', played: 9, wins: 2, losses: 7, draws: 0, points: 16 },
    { name: 'Pueyrredón', played: 9, wins: 1, losses: 8, draws: 0, points: 12 }
  ],
  'Six Nations': [
    { name: 'Francia', played: 3, wins: 3, losses: 0, draws: 0, points: 15 },
    { name: 'Irlanda', played: 3, wins: 2, losses: 1, draws: 0, points: 10 },
    { name: 'Gales', played: 3, wins: 1, losses: 2, draws: 0, points: 5 },
    { name: 'Inglaterra', played: 3, wins: 1, losses: 2, draws: 0, points: 4 },
    { name: 'Italia', played: 3, wins: 0, losses: 3, draws: 0, points: 0 },
    { name: 'Escocia', played: 3, wins: 0, losses: 3, draws: 0, points: 0 }
  ]
};
