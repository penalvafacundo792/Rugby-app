import React, { useState } from 'react';
import { history } from '../data/history';
import './History.css';

function History() {
  const [selectedLeague, setSelectedLeague] = useState('Top 14');

  const leagues = Object.keys(history);
  const currentHistory = history[selectedLeague] || [];

  return (
    <div className="history">
      <h2>Resultados Históricos</h2>

      <div className="league-selector">
        {leagues.map(league => (
          <button
            key={league}
            className={`selector-btn ${selectedLeague === league ? 'active' : ''}`}
            onClick={() => setSelectedLeague(league)}
          >
            {league}
          </button>
        ))}
      </div>

      <div className="history-list">
        {currentHistory.map((match, idx) => (
          <div key={idx} className="history-item">
            <div className="history-date">
              <span>{match.date}</span>
            </div>

            <div className="history-match">
              <div className="team home">
                <span className="team-name">{match.home}</span>
                <span className="score">{match.homeScore}</span>
              </div>

              <div className="vs">-</div>

              <div className="team away">
                <span className="team-name">{match.away}</span>
                <span className="score">{match.awayScore}</span>
              </div>
            </div>

            <div className="history-result">
              {match.homeScore > match.awayScore && (
                <span className="winner">{match.home} Ganó</span>
              )}
              {match.awayScore > match.homeScore && (
                <span className="winner">{match.away} Ganó</span>
              )}
              {match.homeScore === match.awayScore && (
                <span className="draw">Empate</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default History;
