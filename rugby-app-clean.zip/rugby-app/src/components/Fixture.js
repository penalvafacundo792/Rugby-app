import React, { useState } from 'react';
import { fixture } from '../data/fixture';
import './Fixture.css';

function Fixture() {
  const [selectedLeague, setSelectedLeague] = useState('Top 14');

  const leagues = Object.keys(fixture);
  const currentFixture = fixture[selectedLeague] || [];

  return (
    <div className="fixture">
      <h2>Cronograma de Partidos</h2>

      <div className="league-selector">
        {leagues.map(league => (
          <button
            key={league}
            className={`selector-btn ${selectedLeague === league ? 'active' : ''}`}
            onClick={() => setSelectedLeague(league)}
          >
            {league}
          </button>
        ))}
      </div>

      <div className="fixture-list">
        {currentFixture.map((match, idx) => (
          <div key={idx} className="fixture-item">
            <div className="fixture-date">
              <span className="date">{match.date}</span>
              <span className="time">{match.time}</span>
            </div>

            <div className="fixture-match">
              <div className="team home">
                <span className="team-name">{match.home}</span>
              </div>

              <div className="vs">vs</div>

              <div className="team away">
                <span className="team-name">{match.away}</span>
              </div>
            </div>

            <div className={`fixture-status ${match.status}`}>
              {match.status === 'played' && <span>✓ Jugado</span>}
              {match.status === 'scheduled' && <span>Próximo</span>}
              {match.status === 'live' && <span className="live-indicator">EN VIVO</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Fixture;
