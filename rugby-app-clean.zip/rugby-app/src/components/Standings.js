import React, { useState } from 'react';
import { standings } from '../data/standings';
import './Standings.css';

function Standings() {
  const [selectedLeague, setSelectedLeague] = useState('Top 14');

  const leagues = Object.keys(standings);
  const currentStandings = standings[selectedLeague] || [];

  return (
    <div className="standings">
      <h2>Tabla de Posiciones</h2>

      <div className="league-selector">
        {leagues.map(league => (
          <button
            key={league}
            className={`selector-btn ${selectedLeague === league ? 'active' : ''}`}
            onClick={() => setSelectedLeague(league)}
          >
            {league}
          </button>
        ))}
      </div>

      <div className="standings-table-container">
        <table className="standings-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Equipo</th>
              <th>PJ</th>
              <th>G</th>
              <th>P</th>
              <th>PP</th>
              <th>Pts</th>
            </tr>
          </thead>
          <tbody>
            {currentStandings.map((team, idx) => (
              <tr key={idx} className={`position-${idx + 1}`}>
                <td className="position">{idx + 1}</td>
                <td className="team-name">{team.name}</td>
                <td>{team.played}</td>
                <td>{team.wins}</td>
                <td>{team.losses}</td>
                <td>{team.draws}</td>
                <td className="points">{team.points}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="legend">
        <p><strong>PJ:</strong> Partidos Jugados</p>
        <p><strong>G:</strong> Ganados</p>
        <p><strong>P:</strong> Perdidos</p>
        <p><strong>PP:</strong> Empatados</p>
        <p><strong>Pts:</strong> Puntos</p>
      </div>
    </div>
  );
}

export default Standings;
