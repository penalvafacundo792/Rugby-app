import React, { useState } from 'react';
import { matchesToday } from '../data/matches';
import './MatchesDay.css';

function MatchesDay() {
  const [selectedLeague, setSelectedLeague] = useState('all');

  const leagues = ['all', 'URBA Top 14', 'Top 14', 'Premiership'];

  const filtered = selectedLeague === 'all'
    ? matchesToday
    : matchesToday.filter(m => m.league === selectedLeague);

  if (filtered.length === 0) {
    return (
      <div className="matches-day">
        <div className="league-filter">
          {leagues.map(league => (
            <button
              key={league}
              className={`filter-btn ${selectedLeague === league ? 'active' : ''}`}
              onClick={() => setSelectedLeague(league)}
            >
              {league === 'all' ? 'Todas' : league}
            </button>
          ))}
        </div>
        <div className="no-matches">
          <p>No hay partidos hoy</p>
        </div>
      </div>
    );
  }

  return (
    <div className="matches-day">
      <h2>Partidos Hoy</h2>

      <div className="league-filter">
        {leagues.map(league => (
          <button
            key={league}
            className={`filter-btn ${selectedLeague === league ? 'active' : ''}`}
            onClick={() => setSelectedLeague(league)}
          >
            {league === 'all' ? 'Todas' : league}
          </button>
        ))}
      </div>

      <div className="matches-container">
        {filtered.map((match, idx) => (
          <div key={idx} className="match-card">
            <div className="match-league">{match.league}</div>
            <div className="match-time">{match.time}</div>

            <div className="match-teams">
              <div className="team home">
                <div className="team-name">{match.home}</div>
                <div className="team-score">{match.homeScore !== null ? match.homeScore : '-'}</div>
              </div>

              <div className="vs">vs</div>

              <div className="team away">
                <div className="team-name">{match.away}</div>
                <div className="team-score">{match.awayScore !== null ? match.awayScore : '-'}</div>
              </div>
            </div>

            <div className="match-status">
              {match.status === 'live' && <span className="live">EN VIVO</span>}
              {match.status === 'scheduled' && <span className="scheduled">PROGRAMADO</span>}
              {match.status === 'finished' && <span className="finished">FINALIZADO</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default MatchesDay;
