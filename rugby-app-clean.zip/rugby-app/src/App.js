import React, { useState } from 'react';
import './App.css';
import MatchesDay from './components/MatchesDay';
import Standings from './components/Standings';
import Fixture from './components/Fixture';
import History from './components/History';

function App() {
  const [activeTab, setActiveTab] = useState('matches');

  return (
    <div className="App">
      <header className="app-header">
        <h1>🏉 Rugby App</h1>
        <p>Ligas Principales</p>
      </header>

      <nav className="nav-tabs">
        <button
          className={`nav-button ${activeTab === 'matches' ? 'active' : ''}`}
          onClick={() => setActiveTab('matches')}
        >
          Hoy
        </button>
        <button
          className={`nav-button ${activeTab === 'standings' ? 'active' : ''}`}
          onClick={() => setActiveTab('standings')}
        >
          Posiciones
        </button>
        <button
          className={`nav-button ${activeTab === 'fixture' ? 'active' : ''}`}
          onClick={() => setActiveTab('fixture')}
        >
          Fixture
        </button>
        <button
          className={`nav-button ${activeTab === 'history' ? 'active' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          Resultados
        </button>
      </nav>

      <main className="app-content">
        {activeTab === 'matches' && <MatchesDay />}
        {activeTab === 'standings' && <Standings />}
        {activeTab === 'fixture' && <Fixture />}
        {activeTab === 'history' && <History />}
      </main>
    </div>
  );
}

export default App;
