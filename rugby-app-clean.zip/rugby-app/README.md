# 🏉 Rugby App

Una aplicación web moderna para seguir los partidos, posiciones y cronogramas de las principales ligas de rugby mundial.

## Características

✅ **Partidos del día** - Sigue los partidos en tiempo real
✅ **Tabla de posiciones** - Consulta la clasificación de cada liga
✅ **Cronograma** - Visualiza los próximos partidos
✅ **Resultados históricos** - Revisa resultados previos
✅ **Diseño responsivo** - Funciona perfectamente en celular y desktop

## Ligas Incluidas

- 🇫🇷 **Top 14** - Liga francesa
- 🇬🇧 **Premiership** - Liga inglesa
- 🇦🇷 **URBA Top 14** - Liga argentina
- 🌍 **Six Nations** - Torneo internacional

## Tecnología

- **React** 18.2
- **CSS3** con diseño gradiente moderno
- **JavaScript ES6+**

## Instalación

1. Clona el repositorio
2. Instala las dependencias:
   ```bash
   npm install
   ```
3. Inicia la app:
   ```bash
   npm start
   ```

## Build

Para crear una versión optimizada:
```bash
npm run build
```

## Próximas mejoras

- Integración con APIs reales de ligas oficiales
- Sistema de notificaciones
- Cargas de datos en tiempo real
- Filtros avanzados
- Estadísticas de jugadores

---

Hecho con ❤️ para los amantes del rugby 🏉
